﻿This Mod Require EFTApi(https://hub.sp-tarkov.com/files/file/1215-eft-api), You need to install it to work

此模组依赖EFTApi(https://hub.sp-tarkov.com/files/file/1215-eft-api), 你需要安装它才能运行