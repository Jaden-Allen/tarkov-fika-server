# Fps Unlocker

Simple project that increases the framerate limit in sptarkov.